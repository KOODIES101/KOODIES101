# frozen_string_literal: true

require "bundle/extend/os/linux/bundle" if OS.linux?
