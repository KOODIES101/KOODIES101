# frozen_string_literal: true

require "bundle/extend/os/linux/skipper" if OS.linux?
