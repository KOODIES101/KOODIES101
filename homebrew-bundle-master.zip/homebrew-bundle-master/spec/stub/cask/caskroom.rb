# frozen_string_literal: true

module Cask
  module Caskroom
    def self.casks(config: nil)
      []
    end
  end
end
