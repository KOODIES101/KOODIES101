# frozen_string_literal: true

require "cask/cask"
require "cask/caskroom"
require "cask/config"
