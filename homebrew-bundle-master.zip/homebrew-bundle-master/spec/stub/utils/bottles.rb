# frozen_string_literal: true

module Utils
  module Bottles
    module_function

    def tag
      :big_sur
    end
  end
end
