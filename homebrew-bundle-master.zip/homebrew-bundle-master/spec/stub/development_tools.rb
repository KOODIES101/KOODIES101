# frozen_string_literal: true

class DevelopmentTools
  def self.gcc_version(*)
    "9.2.0"
  end
end
