# frozen_string_literal: true

module Hardware
  module CPU
    module_function

    def arm?
      false
    end
  end
end
