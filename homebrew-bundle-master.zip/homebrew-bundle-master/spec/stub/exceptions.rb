# frozen_string_literal: true

class UsageError < RuntimeError
end

class FormulaUnavailableError < RuntimeError
end
